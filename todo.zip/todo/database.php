<?php  

$db=mysqli_connect("localhost","root","","todo") or die("error while connecting with database");

?>